import type { ReactNode } from "react";
import { Link } from "@tanstack/react-router";
import type { DayHours, Media, Price, PubEvent } from "@/lib/pub/types";
import { groupPrices, kroner, longDate, videoView } from "@/lib/pub/format";

export function Kicker({ children }: { children: ReactNode }) {
  return (
    <p className="text-xs font-semibold tracking-widest text-brass uppercase">{children}</p>
  );
}

export function Note({ children }: { children: ReactNode }) {
  return (
    <p className="border-l-4 border-brass-solid bg-paper-2 px-4 py-3 text-sm leading-6">{children}</p>
  );
}

export function HoursTable({
  hours,
  weekday,
  note,
}: {
  hours: DayHours[];
  weekday: string;
  note?: string;
}) {
  return (
    <div>
      <ul className="divide-y divide-line">
        {hours.map((row) => {
          const today = row.day.toLowerCase() === weekday.toLowerCase();
          return (
            <li
              key={row.day}
              className={`flex items-center justify-between gap-4 py-3 ${today ? "font-semibold" : ""}`}
            >
              <span>{row.day}</span>
              <span className="tabular-nums text-muted">
                {row.closed ? "Lukket" : `${row.open}–${row.close}`}
                {today ? " · i dag" : ""}
              </span>
            </li>
          );
        })}
      </ul>
      {note ? <p className="mt-4 text-sm text-muted">{note}</p> : null}
    </div>
  );
}

export function PriceMenu({ prices }: { prices: Price[] }) {
  const groups = groupPrices(prices);
  if (!groups.length) {
    return <p className="text-muted">Kortet er tomt. Ejeren kan lægge priser ind.</p>;
  }
  return (
    <div className="grid gap-12 lg:grid-cols-2">
      {groups.map((group) => (
        <section key={group.category}>
          <h2 className="font-display text-3xl">{group.category}</h2>
          <ul className="mt-4">
            {group.items.map((item) => (
              <li key={item.id} className="flex items-baseline gap-3 py-3">
                <span>
                  <span className="block">{item.name}</span>
                  {item.note ? <span className="block text-sm text-muted">{item.note}</span> : null}
                </span>
                <span className="mb-1 min-w-6 flex-1 border-b border-dotted border-line" />
                <span className="font-display text-xl tabular-nums">{kroner(item.priceKr)}</span>
              </li>
            ))}
          </ul>
        </section>
      ))}
    </div>
  );
}

export function EventCards({ events }: { events: PubEvent[] }) {
  if (!events.length) {
    return (
      <p className="text-muted">
        Ingen kommende aftener i kalenderen. Kig forbi alligevel, eller ring til huset.
      </p>
    );
  }
  return (
    <div className="grid gap-5 md:grid-cols-3">
      {events.map((event) => (
        <article key={event.id} className="overflow-hidden rounded-card border border-line bg-paper-2">
          {event.image ? (
            <img src={event.image} alt="" className="h-44 w-full object-cover" />
          ) : (
            <div className="h-24 bg-walnut" />
          )}
          <div className="p-5">
            <p className="text-sm text-brass">{longDate(event.eventDate)}</p>
            <h3 className="mt-1 font-display text-2xl">{event.title}</h3>
            <p className="mt-2 text-sm tabular-nums text-muted">
              {event.startTime}
              {event.endTime ? `–${event.endTime}` : ""}
            </p>
            {event.description ? <p className="mt-3 text-sm leading-6">{event.description}</p> : null}
          </div>
        </article>
      ))}
    </div>
  );
}

export function MediaTile({ item, large }: { item: Media; large?: boolean }) {
  const frame =
    item.kind === "image" ? (
      <img
        src={item.src}
        alt={item.caption || "Billede fra Sanderum Pubben"}
        className={`w-full object-cover ${large ? "h-80 sm:h-96" : "h-64"}`}
      />
    ) : (
      <Video item={item} />
    );
  return (
    <figure className="overflow-hidden rounded-card border border-line bg-paper-2">
      {frame}
      {item.caption ? <figcaption className="px-4 py-3 text-sm">{item.caption}</figcaption> : null}
    </figure>
  );
}

function Video({ item }: { item: Media }) {
  const view = videoView(item.src);
  if (view.type === "file") {
    return (
      <video
        src={view.src}
        controls
        playsInline
        poster="/media/hero.jpg"
        className="aspect-video w-full bg-walnut object-cover"
      />
    );
  }
  if (view.type === "youtube" || view.type === "vimeo") {
    return (
      <iframe
        src={view.src}
        title={item.caption || "Video"}
        className="aspect-video w-full"
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
        allowFullScreen
      />
    );
  }
  return (
    <a href={view.src} className="grid aspect-video place-items-center bg-walnut px-6 text-center text-cream">
      Se videoen
    </a>
  );
}

export function GalleryGrid({ items }: { items: Media[] }) {
  if (!items.length) return <p className="text-muted">Galleri kommer, når huset lægger billeder ind.</p>;
  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((item, index) => (
        <div key={item.id} className={index === 0 ? "sm:col-span-2" : undefined}>
          <MediaTile item={item} large={index === 0} />
        </div>
      ))}
    </div>
  );
}

export function PageIntro({
  kicker,
  title,
  lede,
}: {
  kicker: string;
  title: string;
  lede?: string;
}) {
  return (
    <header className="mx-auto max-w-6xl px-5 pt-14 pb-8">
      <Kicker>{kicker}</Kicker>
      <h1 className="mt-3 max-w-3xl font-display text-5xl leading-none sm:text-6xl">{title}</h1>
      {lede ? <p className="mt-5 max-w-2xl text-lg leading-8 text-muted">{lede}</p> : null}
    </header>
  );
}

export function MoreLink({ to, children }: { to: "/" | "/kalender" | "/priser" | "/galleri" | "/kontakt"; children: string }) {
  return (
    <Link to={to} className="text-sm font-semibold text-brass">
      {children}
    </Link>
  );
}
