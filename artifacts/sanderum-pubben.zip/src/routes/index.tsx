import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell, usePub } from "@/components/shell";
import { EventCards, GalleryGrid, HoursTable, Kicker, Note, PriceMenu } from "@/components/content";
import { paragraphs, phoneHref, todayHours, upcomingEvents } from "@/lib/pub/format";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [{ title: "Sanderum Pubben · Værtshus i Odense SV" }] }),
  component: Home,
});

function Home() {
  const { site, events, prices, gallery, today, weekday, openNow } = usePub();
  const next = upcomingEvents(events, today).slice(0, 3);
  const previewPrices = prices.slice(0, 6);
  return (
    <Shell>
      <main>
        <section className="grid lg:grid-cols-2">
          <div className="order-2 flex flex-col justify-center px-5 py-14 lg:order-1 lg:px-10 lg:py-20">
            <Kicker>Værtshus · Odense SV · siden 2011</Kicker>
            <h1 className="mt-4 font-display text-6xl leading-none sm:text-7xl">{site.name}</h1>
            <p className="mt-6 max-w-md text-lg leading-8 text-muted">{site.tagline}</p>
            <div className="mt-8 flex flex-wrap items-center gap-3">
              <Link
                to="/kalender"
                className="inline-flex min-h-11 items-center rounded-full bg-ink px-5 text-sm font-semibold text-paper"
              >
                Se kalenderen
              </Link>
              <a
                href={phoneHref(site.phone)}
                className="inline-flex min-h-11 items-center rounded-full border border-line px-5 text-sm font-semibold"
              >
                Ring {site.phone}
              </a>
            </div>
            <p className="mt-8 text-sm">
              <span className="mr-3 inline-flex min-h-8 items-center rounded-full bg-walnut px-3 text-cream">
                {openNow ? "Åben nu" : "Lukket lige nu"}
              </span>
              <span className="text-muted">{todayHours(site.hours, weekday)}</span>
            </p>
          </div>
          <div className="order-1 lg:order-2">
            <img
              src={site.heroImage}
              alt="Baren på Sanderum Pubben"
              className="h-80 w-full object-cover sm:h-96 lg:h-full lg:min-h-screen"
            />
          </div>
        </section>

        <section className="mx-auto grid max-w-6xl gap-12 px-5 py-20 lg:grid-cols-[1.1fr_0.9fr]">
          <div>
            <Kicker>Huset</Kicker>
            <h2 className="mt-3 font-display text-4xl">Stamstedet på Sanderumvej</h2>
            <div className="mt-6 space-y-4 text-lg leading-8">
              {paragraphs(site.about).map((part) => (
                <p key={part.slice(0, 24)}>{part}</p>
              ))}
            </div>
          </div>
          <div>
            <Kicker>Åbent</Kicker>
            <div className="mt-3">
              <HoursTable hours={site.hours} weekday={weekday} note={site.hoursNote} />
            </div>
          </div>
        </section>

        <section className="border-y border-line bg-paper-2">
          <div className="mx-auto grid max-w-6xl gap-px sm:grid-cols-2 lg:grid-cols-4">
            {[
              ["01", "Billard", "Et bord til en rolig omgang, eller til turneringen når den er sat."],
              ["02", "Dart", "Tavlen hænger klar. 501, og plads til nye spillere."],
              ["03", "Rafle", "Terningerne kommer frem, når selskabet er til det."],
              ["04", "Terrasse", "Borde ude foran, når vejret på Sanderumvej er med."],
            ].map(([n, title, text]) => (
              <article key={n} className="px-5 py-10">
                <p className="font-display text-3xl text-brass">{n}</p>
                <h3 className="mt-3 font-display text-2xl">{title}</h3>
                <p className="mt-2 text-sm leading-6 text-muted">{text}</p>
              </article>
            ))}
          </div>
        </section>

        <section className="mx-auto max-w-6xl px-5 py-20">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <Kicker>Kalender</Kicker>
              <h2 className="mt-3 font-display text-4xl">Det næste</h2>
            </div>
            <Link to="/kalender" className="text-sm font-semibold text-brass">
              Hele kalenderen
            </Link>
          </div>
          {!site.calendarLive ? (
            <div className="mb-6">
              <Note>
                Programmet er eksempler, så kalenderen ikke står tom. Huset bekræfter de rigtige
                aftener. Ring gerne, hvis du er i tvivl.
              </Note>
            </div>
          ) : null}
          <EventCards events={next} />
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-20">
          <div className="mb-8 flex flex-wrap items-end justify-between gap-4">
            <div>
              <Kicker>Kortet</Kicker>
              <h2 className="mt-3 font-display text-4xl">Et udpluk</h2>
            </div>
            <Link to="/priser" className="text-sm font-semibold text-brass">
              Alle priser
            </Link>
          </div>
          {!site.pricesLive ? (
            <div className="mb-6">
              <Note>Tallene er et vejledende startkort, indtil huset har bekræftet priserne. Spørg i baren.</Note>
            </div>
          ) : null}
          <PriceMenu prices={previewPrices} />
        </section>

        <section className="mx-auto max-w-6xl px-5 pb-8">
          <div className="mb-8 flex items-end justify-between gap-4">
            <div>
              <Kicker>Billeder</Kicker>
              <h2 className="mt-3 font-display text-4xl">Inde fra huset</h2>
            </div>
            <Link to="/galleri" className="text-sm font-semibold text-brass">
              Galleri
            </Link>
          </div>
          <GalleryGrid items={gallery.slice(0, 4)} />
        </section>
      </main>
    </Shell>
  );
}
